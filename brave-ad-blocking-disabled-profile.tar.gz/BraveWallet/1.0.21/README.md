Keep that folder as it has to be created as a docker output under the current user.
Otherwise it will be created under a docker's root user.